# -*- coding: utf-8 -*-
from modules import service_functions
from modules.kodi_utils import Thread, xbmc_monitor, logger, local_string as ls

hermes_str = ls(32036).upper()
on_notification_actions = service_functions.OnNotificationActions()
on_settings_changed_actions = service_functions.OnSettingsChangedActions()

class HermesMonitor(xbmc_monitor):
	def __init__ (self):
		xbmc_monitor.__init__(self)
		self.startUpServices()

	def startUpServices(self):
		try: service_functions.InitializeDatabases().run()
		except: pass
		try: service_functions.CheckSettings().run()
		except: pass
		# try: service_functions.FirstRunActions().run()
		# except: pass
		# try: service_functions.ReuseLanguageInvokerCheck().run()
		# except: pass
		Thread(target=service_functions.TraktMonitor().run).start()
		Thread(target=service_functions.CustomActions().run).start()
		Thread(target=service_functions.CustomFonts().run).start()
		# Thread(target=service_functions.PremiumExpiryCheck().run).start()

		############KODI-RD-IL###################
		try:
			from indexers import premiumize, real_debrid
			Thread(target=premiumize.active_days_notify_only()).start()
			Thread(target=real_debrid.active_days_notify_only()).start()
		except:
			pass
		#########################################

		# Force pagination + menu-cache defaults once per addon version. After this
		# runs the first time on a new version, the user is free to change them.
		try:
			from modules.kodi_utils import get_setting, set_setting, addon_object
			MARKER_KEY = 'hermes.defaults_applied_for_version'
			cur_ver = addon_object.getAddonInfo('version')
			if get_setting(MARKER_KEY) != cur_ver:
				set_setting('paginate.lists', '1')          # Add-on Lists Only
				set_setting('paginate.limit_addon', '100')  # 100 items per page
				set_setting('kodi_menu_cache', 'true')      # cacheToDisc=True
				set_setting(MARKER_KEY, cur_ver)
		except: pass

		# Auto-migrate dead TMDb API keys. Kodi never overwrites a user-saved
		# setting when an addon update changes the default, so users who were
		# silently riding the previous default end up stuck on a revoked key.
		# If the saved key matches one of the known-revoked defaults, replace
		# it with the current default. Users who set their own key are
		# untouched (their key won't be in the revoked list).
		try:
			from modules.kodi_utils import get_setting, set_setting, tmdb_default_api, tmdb_revoked_default_keys
			current_tmdb = get_setting('tmdb_api')
			if current_tmdb in tmdb_revoked_default_keys:
				set_setting('tmdb_api', tmdb_default_api)
		except: pass

		# ScrapperHermes (embedded) startup init
		try:
			from scrapperhermes.modules import undesirables, control as sh_control
			try:
				if undesirables.Undesirables().check_database():
					undesirables.add_new_default_keywords()
			except: pass
			# Prime the settings dict cache so first scrape doesn't race the lazy build
			try: sh_control.make_settings_dict()
			except: pass
		except:
			pass

		# try: service_functions.ClearSubs().run()
		# except: pass
		# try: service_functions.AutoRun().run()
		# except: pass
		Thread(target=service_functions.DatabaseMaintenance().run).start()
		# service_functions.UpdateCheck().run()

	def onSettingsChanged(self):
		on_settings_changed_actions.run()
		# Refresh ScrapperHermes settings cache when user toggles providers etc.
		try:
			from scrapperhermes.modules import control as sh_control
			sh_control.make_settings_dict()
			sh_control.refresh_debugReversed()
		except: pass

	def onNotification(self, sender, method, data):
		on_notification_actions.run(sender, method, data)

logger(hermes_str, 'Main Monitor Service Starting')
logger(hermes_str, 'Settings Monitor Service Starting')
HermesMonitor().waitForAbort()
logger(hermes_str, 'Settings Monitor Service Finished')
logger(hermes_str, 'Main Monitor Service Finished')