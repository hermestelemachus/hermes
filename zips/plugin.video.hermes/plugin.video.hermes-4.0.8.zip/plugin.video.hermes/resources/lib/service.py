# -*- coding: utf-8 -*-
from modules import service_functions
from modules.kodi_utils import Thread, xbmc_monitor, logger, local_string as ls

hermes_str = ls(32036).upper()
on_notification_actions = service_functions.OnNotificationActions()
on_settings_changed_actions = service_functions.OnSettingsChangedActions()

class HermesMonitor(xbmc_monitor):
	def __init__ (self):
		xbmc_monitor.__init__(self)
		self.startUpServices()

	def startUpServices(self):
		try: service_functions.InitializeDatabases().run()
		except: pass
		try: service_functions.CheckSettings().run()
		except: pass
		# try: service_functions.FirstRunActions().run()
		# except: pass
		# try: service_functions.ReuseLanguageInvokerCheck().run()
		# except: pass
		Thread(target=service_functions.TraktMonitor().run).start()
		Thread(target=service_functions.CustomActions().run).start()
		Thread(target=service_functions.CustomFonts().run).start()
		# Thread(target=service_functions.PremiumExpiryCheck().run).start()

		############KODI-RD-IL###################
		try:
			from indexers import premiumize, real_debrid
			Thread(target=premiumize.active_days_notify_only()).start()
			Thread(target=real_debrid.active_days_notify_only()).start()
		except:
			pass
		#########################################

		# ScrapperHermes (embedded) startup init
		try:
			from scrapperhermes.modules import undesirables, control as sh_control
			try:
				if undesirables.Undesirables().check_database():
					undesirables.add_new_default_keywords()
			except: pass
			# Prime the settings dict cache so first scrape doesn't race the lazy build
			try: sh_control.make_settings_dict()
			except: pass
		except:
			pass

		# try: service_functions.ClearSubs().run()
		# except: pass
		# try: service_functions.AutoRun().run()
		# except: pass
		Thread(target=service_functions.DatabaseMaintenance().run).start()
		# service_functions.UpdateCheck().run()

	def onSettingsChanged(self):
		on_settings_changed_actions.run()
		# Refresh ScrapperHermes settings cache when user toggles providers etc.
		try:
			from scrapperhermes.modules import control as sh_control
			sh_control.make_settings_dict()
			sh_control.refresh_debugReversed()
		except: pass

	def onNotification(self, sender, method, data):
		on_notification_actions.run(sender, method, data)

logger(hermes_str, 'Main Monitor Service Starting')
logger(hermes_str, 'Settings Monitor Service Starting')
HermesMonitor().waitForAbort()
logger(hermes_str, 'Settings Monitor Service Finished')
logger(hermes_str, 'Main Monitor Service Finished')