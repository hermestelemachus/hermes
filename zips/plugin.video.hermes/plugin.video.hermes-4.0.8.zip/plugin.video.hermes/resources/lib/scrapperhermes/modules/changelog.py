# -*- coding: utf-8 -*-
"""
	Fenomscrapers Module
"""

from scrapperhermes.modules.control import addonPath, addonVersion, joinPath
from scrapperhermes.windows.textviewer import TextViewerXML


def get():
	scrapperhermes_path = addonPath()
	scrapperhermes_version = addonVersion()
	changelogfile = joinPath(scrapperhermes_path, 'changelog.txt')
	r = open(changelogfile, 'r', encoding='utf-8', errors='ignore')
	text = r.read()
	r.close()
	heading = '[B]ScrapperHermes -  v%s - ChangeLog[/B]' % scrapperhermes_version
	windows = TextViewerXML('textviewer.xml', scrapperhermes_path, heading=heading, text=text)
	windows.run()
	del windows