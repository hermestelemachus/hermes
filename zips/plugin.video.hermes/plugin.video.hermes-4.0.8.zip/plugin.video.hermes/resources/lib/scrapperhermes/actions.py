# -*- coding: utf-8 -*-
"""
ScrapperHermes action dispatcher - handles RunPlugin(plugin://plugin.video.hermes/?action=...)
calls originating from the embedded scrapper's settings buttons. Mirrors the original
script.module.cocoscrapers/lib/default.py routing.
"""
from scrapperhermes import sources_scrapperhermes
from scrapperhermes.modules import control


def dispatch(action, params):
	if action == "Defaults":
		control.setProviderDefaults()

	elif action == "toggleAll":
		for i in sources_scrapperhermes.all_providers:
			control.setSetting('provider.' + i, params['setting'])

	elif action == "toggleAllHosters":
		# Embedded ScrapperHermes ships only torrent providers; hoster_providers does not exist.
		pass

	elif action == "toggleAllTorrent":
		for i in sources_scrapperhermes.torrent_providers:
			control.setSetting('provider.' + i, params['setting'])

	elif action == "toggleAllPackTorrent":
		control.execute('RunPlugin(plugin://plugin.video.hermes/?action=toggleAllTorrent&setting=false)')
		control.sleep(500)
		from scrapperhermes import pack_sources
		for i in pack_sources():
			control.setSetting('provider.' + i, params['setting'])

	elif action == 'cleanSettings':
		control.clean_settings()

	elif action == 'undesirablesSelect':
		from scrapperhermes.modules.undesirables import undesirablesSelect
		undesirablesSelect()

	elif action == 'undesirablesInput':
		from scrapperhermes.modules.undesirables import undesirablesInput
		undesirablesInput()

	elif action == 'undesirablesUserRemove':
		from scrapperhermes.modules.undesirables import undesirablesUserRemove
		undesirablesUserRemove()

	elif action == 'undesirablesUserRemoveAll':
		from scrapperhermes.modules.undesirables import undesirablesUserRemoveAll
		undesirablesUserRemoveAll()

	elif action == 'tools_clearLogFile':
		from scrapperhermes.modules import log_utils
		cleared = log_utils.clear_logFile()
		if cleared == 'canceled': pass
		elif cleared: control.notification(message='ScrapperHermes Log File Successfully Cleared')
		else: control.notification(message='Error clearing ScrapperHermes Log File, see kodi.log for more info')

	elif action == 'tools_viewLogFile':
		from scrapperhermes.modules import log_utils
		log_utils.view_LogFile(params.get('name'))

	elif action == 'tools_viewTorrentStats':
		from scrapperhermes.modules import log_utils
		log_utils.view_TorrentStats(params.get('name'))

	elif action == 'tools_uploadLogFile':
		from scrapperhermes.modules import log_utils
		log_utils.upload_LogFile()

	elif action == 'plexAuth':
		from scrapperhermes.modules import plex
		plex.Plex().auth()

	elif action == 'plexRevoke':
		from scrapperhermes.modules import plex
		plex.Plex().revoke()

	elif action == 'plexSelectShare':
		from scrapperhermes.modules import plex
		plex.Plex().get_plexshare_resource()

	elif action == 'plexSeeShare':
		from scrapperhermes.modules import plex
		plex.Plex().see_active_shares()

	elif action == 'ShowOKDialog':
		control.okDialog(params.get('title', 'default'), int(params.get('message', '')))

	elif action == 'TestProwlarrConnection':
		from scrapperhermes.modules.prowlarr import Prowlarr
		Prowlarr().test()

	elif action == 'ProwlarrIndexers':
		from scrapperhermes.modules.prowlarr import Prowlarr
		Prowlarr().get_indexers()

	elif action == 'mediafusionAuth':
		from scrapperhermes.modules.mediafusion import MediaFusion
		MediaFusion().auth()

	elif action == 'mediafusionReset':
		from scrapperhermes.modules.mediafusion import MediaFusion
		MediaFusion().clear()

	elif action == 'ShowChangelog':
		from scrapperhermes.modules import changelog
		changelog.get()

	elif action == 'ShowHelp':
		from scrapperhermes.help import help
		help.get(params.get('name'))
