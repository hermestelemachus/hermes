# -*- coding: utf-8 -*-
"""
	Fenomscrapers Module
"""

from scrapperhermes.modules.control import addonPath, addonVersion, joinPath
from scrapperhermes.windows.textviewer import TextViewerXML


def get(file):
	scrapperhermes_path = addonPath()
	scrapperhermes_version = addonVersion()
	helpFile = joinPath(scrapperhermes_path, 'lib', 'scrapperhermes', 'help', file + '.txt')
	r = open(helpFile, 'r', encoding='utf-8', errors='ignore')
	text = r.read()
	r.close()
	heading = '[B]ScrapperHermes -  v%s - %s[/B]' % (scrapperhermes_version, file)
	windows = TextViewerXML('textviewer.xml', scrapperhermes_path, heading=heading, text=text)
	windows.run()
	del windows